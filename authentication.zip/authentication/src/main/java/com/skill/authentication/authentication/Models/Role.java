package com.skill.authentication.authentication.Models;

public enum Role {
    USER,
    ADMIN
}
